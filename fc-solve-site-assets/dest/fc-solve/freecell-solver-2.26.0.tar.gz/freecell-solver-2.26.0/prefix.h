#define FREECELL_SOLVER_PREFIX "/usr"

#define FREECELL_SOLVER_PKG_DATA_DIR "/usr/share/freecell-solver"

