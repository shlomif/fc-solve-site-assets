#define FREECELL_SOLVER_PREFIX "/home/shlomi/apps/test/fcs"

#define FREECELL_SOLVER_PKG_DATA_DIR "/home/shlomi/apps/test/fcs/share/freecell-solver"

