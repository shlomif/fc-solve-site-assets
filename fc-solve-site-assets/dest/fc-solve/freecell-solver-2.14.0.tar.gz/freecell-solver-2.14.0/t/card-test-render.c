/* vim:syn=tt2
*/
#include <tap.h>
#include <string.h>

#include "../card.c"

int main_tests()
{
    char buffer[1024];







    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AH"),
            "Trying to render " "AH" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AH"),
            "Trying to render " "AH" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2H"),
            "Trying to render " "2H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2H"),
            "Trying to render " "2H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3H"),
            "Trying to render " "3H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3H"),
            "Trying to render " "3H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4H"),
            "Trying to render " "4H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4H"),
            "Trying to render " "4H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5H"),
            "Trying to render " "5H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5H"),
            "Trying to render " "5H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6H"),
            "Trying to render " "6H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6H"),
            "Trying to render " "6H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7H"),
            "Trying to render " "7H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7H"),
            "Trying to render " "7H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8H"),
            "Trying to render " "8H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8H"),
            "Trying to render " "8H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9H"),
            "Trying to render " "9H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9H"),
            "Trying to render " "9H" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "10H"),
            "Trying to render " "10H" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "TH"),
            "Trying to render " "TH" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JH"),
            "Trying to render " "JH" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JH"),
            "Trying to render " "JH" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QH"),
            "Trying to render " "QH" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QH"),
            "Trying to render " "QH" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KH"),
            "Trying to render " "KH" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 0);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KH"),
            "Trying to render " "KH" " into a string");
    }







    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AC"),
            "Trying to render " "AC" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AC"),
            "Trying to render " "AC" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2C"),
            "Trying to render " "2C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2C"),
            "Trying to render " "2C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3C"),
            "Trying to render " "3C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3C"),
            "Trying to render " "3C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4C"),
            "Trying to render " "4C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4C"),
            "Trying to render " "4C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5C"),
            "Trying to render " "5C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5C"),
            "Trying to render " "5C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6C"),
            "Trying to render " "6C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6C"),
            "Trying to render " "6C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7C"),
            "Trying to render " "7C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7C"),
            "Trying to render " "7C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8C"),
            "Trying to render " "8C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8C"),
            "Trying to render " "8C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9C"),
            "Trying to render " "9C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9C"),
            "Trying to render " "9C" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "10C"),
            "Trying to render " "10C" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "TC"),
            "Trying to render " "TC" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JC"),
            "Trying to render " "JC" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JC"),
            "Trying to render " "JC" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QC"),
            "Trying to render " "QC" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QC"),
            "Trying to render " "QC" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KC"),
            "Trying to render " "KC" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 1);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KC"),
            "Trying to render " "KC" " into a string");
    }







    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AD"),
            "Trying to render " "AD" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AD"),
            "Trying to render " "AD" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2D"),
            "Trying to render " "2D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2D"),
            "Trying to render " "2D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3D"),
            "Trying to render " "3D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3D"),
            "Trying to render " "3D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4D"),
            "Trying to render " "4D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4D"),
            "Trying to render " "4D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5D"),
            "Trying to render " "5D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5D"),
            "Trying to render " "5D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6D"),
            "Trying to render " "6D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6D"),
            "Trying to render " "6D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7D"),
            "Trying to render " "7D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7D"),
            "Trying to render " "7D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8D"),
            "Trying to render " "8D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8D"),
            "Trying to render " "8D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9D"),
            "Trying to render " "9D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9D"),
            "Trying to render " "9D" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "10D"),
            "Trying to render " "10D" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "TD"),
            "Trying to render " "TD" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JD"),
            "Trying to render " "JD" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JD"),
            "Trying to render " "JD" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QD"),
            "Trying to render " "QD" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QD"),
            "Trying to render " "QD" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KD"),
            "Trying to render " "KD" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 2);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KD"),
            "Trying to render " "KD" " into a string");
    }







    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AS"),
            "Trying to render " "AS" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 1);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "AS"),
            "Trying to render " "AS" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2S"),
            "Trying to render " "2S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 2);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "2S"),
            "Trying to render " "2S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3S"),
            "Trying to render " "3S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 3);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "3S"),
            "Trying to render " "3S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4S"),
            "Trying to render " "4S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 4);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "4S"),
            "Trying to render " "4S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5S"),
            "Trying to render " "5S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 5);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "5S"),
            "Trying to render " "5S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6S"),
            "Trying to render " "6S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 6);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "6S"),
            "Trying to render " "6S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7S"),
            "Trying to render " "7S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 7);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "7S"),
            "Trying to render " "7S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8S"),
            "Trying to render " "8S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 8);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "8S"),
            "Trying to render " "8S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9S"),
            "Trying to render " "9S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 9);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "9S"),
            "Trying to render " "9S" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "10S"),
            "Trying to render " "10S" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 10);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "TS"),
            "Trying to render " "TS" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JS"),
            "Trying to render " "JS" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 11);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "JS"),
            "Trying to render " "JS" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QS"),
            "Trying to render " "QS" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 12);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "QS"),
            "Trying to render " "QS" " into a string");
    }





    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 0);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KS"),
            "Trying to render " "KS" " into a string");
    }



    {
        fcs_card_t mycard;
        char * ret;

        mycard = fcs_empty_card;

        fcs_card_set_suit(mycard, 3);
        fcs_card_set_num(mycard, 13);

        ret = freecell_solver_card_perl2user(mycard, buffer, 1);
        /* TEST */
        
        ok (ret == buffer, 
           "Return value is the beginning of the buffer.");
        /* TEST */
        
        ok (!strcmp(buffer, "KS"),
            "Trying to render " "KS" " into a string");
    }



}

int main(void)
{
  plan_tests(208); 
  main_tests(); 
  return exit_status();
}
