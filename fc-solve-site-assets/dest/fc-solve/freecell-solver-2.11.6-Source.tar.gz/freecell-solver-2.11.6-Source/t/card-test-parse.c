/* vim:syn=tt2
*/
#include <tap.h>
#include <string.h>

#include "../card.c"

int main_tests()
{
    char buffer[1024];







    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "AH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AH");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "AH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AH");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "2H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "2H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "3H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "3H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "4H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "4H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "5H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "5H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "6H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "6H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "7H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "7H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "8H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "8H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "9H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "9H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9H");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("10H");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "10H");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "10H");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("TH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "TH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "TH");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "JH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JH");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "JH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JH");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "QH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QH");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "QH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QH");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "KH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KH");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KH");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 0,
            "Parsing the suit of card " "KH");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KH");
    }







    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "AC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AC");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "AC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AC");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "2C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "2C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "3C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "3C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "4C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "4C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "5C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "5C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "6C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "6C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "7C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "7C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "8C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "8C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "9C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "9C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9C");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("10C");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "10C");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "10C");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("TC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "TC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "TC");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "JC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JC");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "JC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JC");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "QC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QC");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "QC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QC");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "KC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KC");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KC");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 1,
            "Parsing the suit of card " "KC");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KC");
    }







    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "AD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AD");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "AD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AD");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "2D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "2D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "3D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "3D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "4D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "4D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "5D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "5D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "6D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "6D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "7D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "7D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "8D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "8D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "9D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "9D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9D");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("10D");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "10D");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "10D");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("TD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "TD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "TD");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "JD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JD");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "JD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JD");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "QD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QD");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "QD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QD");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "KD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KD");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KD");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 2,
            "Parsing the suit of card " "KD");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KD");
    }







    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "AS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AS");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("AS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "AS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 1,
            "Parsing the rank of card " "AS");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "2S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("2S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "2S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 2,
            "Parsing the rank of card " "2S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "3S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("3S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "3S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 3,
            "Parsing the rank of card " "3S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "4S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("4S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "4S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 4,
            "Parsing the rank of card " "4S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "5S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("5S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "5S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 5,
            "Parsing the rank of card " "5S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "6S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("6S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "6S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 6,
            "Parsing the rank of card " "6S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "7S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("7S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "7S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 7,
            "Parsing the rank of card " "7S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "8S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("8S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "8S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 8,
            "Parsing the rank of card " "8S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "9S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("9S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "9S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 9,
            "Parsing the rank of card " "9S");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("10S");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "10S");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "10S");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("TS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "TS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 10,
            "Parsing the rank of card " "TS");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "JS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JS");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("JS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "JS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 11,
            "Parsing the rank of card " "JS");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "QS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QS");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("QS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "QS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 12,
            "Parsing the rank of card " "QS");
    }





    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "KS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KS");
    }



    {
        fcs_card_t mycard;

        mycard = freecell_solver_card_user2perl("KS");
        /* TEST */
        
        ok (fcs_card_suit(mycard) == 3,
            "Parsing the suit of card " "KS");
        /* TEST */
        
        ok (fcs_card_card_num(mycard) == 13,
            "Parsing the rank of card " "KS");
    }



}

int main(void)
{
  plan_tests(208); 
  main_tests(); 
  return exit_status();
}
