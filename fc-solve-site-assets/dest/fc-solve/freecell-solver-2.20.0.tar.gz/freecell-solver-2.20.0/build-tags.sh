#!/bin/bash
ctags *.[ch]
